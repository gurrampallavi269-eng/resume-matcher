import re
import streamlit as st

st.set_page_config(page_title="Resume Matcher", page_icon="📄", layout="wide")

SKILLS = [
    "python", "java", "c++", "c", "sql", "html", "css", "javascript",
    "react", "node.js", "flask", "django", "streamlit", "machine learning",
    "deep learning", "artificial intelligence", "data analysis", "pandas",
    "numpy", "excel", "power bi", "tableau", "git", "github", "rest api",
    "fastapi", "spring boot", "cloud", "aws", "azure", "communication",
    "problem solving", "data structures", "algorithms", "oop", "dbms"
]

def normalize(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9+#.\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def find_skills(text: str):
    normalized = normalize(text)
    found = []
    for skill in SKILLS:
        # Search for skill phrases with reasonable word boundaries.
        pattern = r"(?<![a-z0-9])" + re.escape(skill) + r"(?![a-z0-9])"
        if re.search(pattern, normalized):
            found.append(skill)
    return sorted(set(found))

st.title("📄 Resume Matcher")
st.write("Compare resume text with a job description and identify skills to highlight.")
st.info("This demo uses a transparent keyword-based comparison. Its match score is an estimate, not a hiring recommendation.")

left, right = st.columns(2)
with left:
    resume_text = st.text_area(
        "Paste resume text",
        height=280,
        placeholder="Paste the text from your resume here..."
    )
with right:
    job_text = st.text_area(
        "Paste job description",
        height=280,
        placeholder="Paste the job description here..."
    )

if st.button("Analyze match", type="primary", use_container_width=True):
    if not resume_text.strip() or not job_text.strip():
        st.warning("Please paste both your resume text and the job description.")
    else:
        resume_skills = set(find_skills(resume_text))
        job_skills = set(find_skills(job_text))
        matched = sorted(resume_skills & job_skills)
        missing = sorted(job_skills - resume_skills)
        extra = sorted(resume_skills - job_skills)

        if not job_skills:
            st.warning("No skills from the app's built-in list were detected in the job description. Try including specific technical skills.")
        else:
            score = round(100 * len(matched) / len(job_skills))
            st.subheader("Results")
            c1, c2, c3 = st.columns(3)
            c1.metric("Estimated skill match", f"{score}%")
            c2.metric("Matched skills", len(matched))
            c3.metric("Skills to consider highlighting", len(missing))
            st.progress(score / 100)

            col1, col2 = st.columns(2)
            with col1:
                st.markdown("#### ✅ Matched skills")
                if matched:
                    st.write(", ".join(matched))
                else:
                    st.write("No matching skills detected.")
                st.markdown("#### ➕ Other skills detected in resume")
                st.write(", ".join(extra) if extra else "None detected.")
            with col2:
                st.markdown("#### 🔎 Skills in the job description not detected in resume")
                st.write(", ".join(missing) if missing else "All detected job-description skills also appear in the resume.")

            report = [
                "RESUME MATCHER REPORT",
                f"Estimated skill match: {score}%",
                f"Job-description skills detected: {', '.join(sorted(job_skills)) or 'None'}",
                f"Matched skills: {', '.join(matched) or 'None'}",
                f"Skills not detected in resume: {', '.join(missing) or 'None'}",
                "",
                "Note: This is a keyword-based estimate, not a hiring decision."
            ]
            st.download_button(
                "Download text report",
                data="\n".join(report),
                file_name="resume_match_report.txt",
                mime="text/plain"
            )

st.caption("Tip: Only include accurate skills in your resume. The tool checks for words and phrases; it does not verify your actual proficiency.")
