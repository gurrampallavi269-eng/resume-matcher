# Resume Matcher

A beginner-friendly Python + Streamlit project that compares resume text with a job description.

## Features
- Paste resume text and a job description.
- Detect skills from a built-in keyword list.
- Calculate an estimated skill-match percentage.
- Show matching skills and skills mentioned in the job description but not detected in the resume.
- Download a plain-text results report.

## Important limitation
This project uses keyword matching, not an AI model. The percentage is a simple estimate based on the skills detected from a built-in list. It does not judge candidate quality or verify whether a person truly has a skill.

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   streamlit run app.py
   ```

5. Open the local URL shown in the terminal (usually `http://localhost:8501`).

## Suggested improvements
- Add PDF/DOCX text extraction.
- Let users add custom skills.
- Add unit tests for skill detection.
- Improve matching with synonyms and semantic similarity.
- Add privacy and data-retention notes if deploying publicly.

## Project explanation for an interview
"I built a Resume Matcher using Python and Streamlit. It takes resume text and a job description, detects skills using a predefined keyword list, and reports the overlap and skills not detected in the resume. I chose a transparent keyword-based baseline because it is simple to understand and test. Its limitation is that it can miss synonyms and cannot understand context, so semantic matching would be a future improvement."

Only use that explanation if you have run the project, reviewed the code, and can explain it honestly.
